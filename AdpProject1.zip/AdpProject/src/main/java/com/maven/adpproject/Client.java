package com.maven.adpproject;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import javax.swing.JOptionPane;

public class Client implements Serializable {
    private Socket server;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private GUIClass gui;

    public Client(GUIClass gui) {
        this.gui = gui;
        try {
            server = new Socket("127.0.0.1", 6666);
            System.out.println("Connected to server");
        } catch (IOException ioe) {
            System.out.println("IOException: " + ioe.getMessage());
        }
    }

    // New method to send the car name and vote count to the server
    public void sendVote(String car, int votes) {
        try {
            out.writeObject(car); // Send car name
            out.writeObject(votes); // Send vote count
            out.flush();
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    // Method to handle "terminate" message to close the connection
    public void sendMessage(String message) {
        try {
            out.writeObject(message); // Send message to the server
            out.flush();
        } catch (IOException ex) {
            System.out.println("Error: " + ex.getMessage());
        }
    }

    public void communicate() throws IOException {
        try {
            out = new ObjectOutputStream(server.getOutputStream());
            out.flush();
            in = new ObjectInputStream(server.getInputStream());

            while (true) {
                // Listen to responses from the server
                String response = (String) in.readObject();
                //gui.appendText(response + "\n");

                String sendText = gui.getTextInput(); // Get the car from text field
                if (!sendText.isEmpty()) {
                    sendVote(sendText, gui.getVotesForCar(sendText)); // Send the car and votes
                }

                if (sendText.equalsIgnoreCase("terminate")) {
                    closeConnection(); // Close connection when "terminate" is entered
                    break;
                }
            }
        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Class not found: " + e.getMessage());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error occurred: " + e.getMessage());
        } finally {
            closeConnection();
        }
    }

    public void closeConnection() {
        try {
            out.close();
            in.close();
            server.close();
            System.out.println("Connection closed.");
        } catch (IOException ex) {
            System.out.println("Error occurred when closing connection");
        }
    }
}
