
package com.maven.adpproject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author smang
 */
public class DBconnection {
      public static Connection derbyConnection() throws SQLException{ 
        String DATABASE_URL = "jdbc:derby://localhost:1527/ProjectDB";
        String username = "Administrator";
        String password = "12345";
        Connection con = DriverManager.getConnection(DATABASE_URL, username, password);
        return con;
    }
}
