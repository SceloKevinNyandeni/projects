package com.maven.adpproject;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.security.auth.Subject;
import javax.swing.JOptionPane;

public class DatabaseHandler {
    private Connection con;
    private PreparedStatement pstatement;
    Server server;
    
    public DatabaseHandler(){
        try {
            this.con = DBconnection.derbyConnection();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error:"+ex.getMessage());
        }
    }
    public Server save(Server server){
        int ok;
        String Sqls = "INSERT INTO Car(Car, Votes) VALUES (?, ?)";
        
        try{
            pstatement = this.con.prepareStatement(Sqls);
            pstatement.setString(1, server.myMsg);
            pstatement.setInt(2, server.votes);
            ok = pstatement.executeUpdate();
            if(ok>0){
                return server;
            }else{
                return null;
        }
        }catch(SQLException sql){
            System.out.println("Failed: " + sql.getMessage());
        }finally{
            try{
                if(pstatement != null){
                    pstatement.close();
                }
            }catch(SQLException e){
                 System.out.println("Error: " + e.getMessage());   
            }
            
        }
        return null;
    }
    public ArrayList<Server> getAll(){
        ArrayList<Server> arr = new ArrayList();
        
        try {
            String all = "SELECT * FROM Car";
            pstatement = this.con.prepareStatement(all);
            ResultSet rs = pstatement.executeQuery();
            while(rs.next()){
                String carName = rs.getString("Car");
                int voteCount = rs.getInt("Votes");
                arr.add(new Server(carName, voteCount));
                System.out.println("Car: " + carName + " | Votes: " + voteCount);
                }
            
            rs.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Close: " + ex.getMessage());
        }finally{
            if(pstatement != null){
                try {
                    pstatement.close();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(null, "" + ex.getMessage());
                }
            }
        }
        return arr;
        }
    }

