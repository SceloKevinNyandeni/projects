/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.maven.adpproject;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author smang
 */
public class GUIClass extends JFrame implements ActionListener{
    protected static JTextArea taClient;
    protected static JTextField text;
    private JPanel north;
    private JPanel center;
    private JPanel bottom;
    private JMenuItem iteMenu;
    private JMenu jme;
    private JMenuBar menBar;
    private JLabel lbl;
    String [] arr = {"Select","CHEVROLET","FIAT","KIA","ISUZU","MAHINDRA"};
    protected static JComboBox box;
    DefaultTableModel model;
    private JButton vote;
    private JButton view;
    private JButton exit;
    JTable table;
    Client cl;
    Server serve;
    DatabaseHandler dao;
    ArrayList<Server> data = new ArrayList();
    HashMap<String, Integer> selectionCounts = new HashMap<>();
    
    public GUIClass() {
        dao = new DatabaseHandler();
        for (String car : arr) {
            if (!car.equals("Select")) {
                selectionCounts.put(car, 0);
            }
        }
        setGUI();
    }
    /*public GUIClass(String cars, int votes){
        this.cars = cars;
        this.votes = votes;
    }*/
    
    public void setGUI(){
        
        north = new JPanel();
        center = new JPanel();
        bottom = new JPanel();
        iteMenu = new JMenuItem("Exit");
        jme = new JMenu("File");
        menBar = new JMenuBar();
        lbl = new JLabel("Enter car");
        text = new JTextField(10);
        box = new JComboBox(arr);
        vote = new JButton("Vote");
        view = new JButton("View");
        exit = new JButton("Exit");
        
        model = new DefaultTableModel();
        table = new JTable(model);
        taClient = new JTextArea(7,20);
        taClient.setEditable(false);
        taClient.setBackground(Color.WHITE);
        
        north.setLayout(new GridLayout(1, 4));
        center.setLayout(new GridLayout(2, 1));
        bottom.setLayout(new GridLayout(1, 3));
        
        menBar.add(jme);
        jme.add(iteMenu);
        this.setJMenuBar(menBar);
        
        north.add(lbl);
        north.add(text);
        north.add(box);
        
        model.addColumn("Car");
        model.addColumn("Votes");
        
        JScrollPane pane = new JScrollPane(table);
        center.add(pane);
        center.add(taClient);
        bottom.add(vote);
        bottom.add(view);
        bottom.add(exit);
        
        this.setLayout(new BorderLayout());
        this.add(north, BorderLayout.NORTH);
        this.add(center, BorderLayout.CENTER);
        this.add(bottom, BorderLayout.SOUTH);
        
        vote.addActionListener(this);
        view.addActionListener(this);
    }   
        
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == vote){
            String message = text.getText();
            String selCar = String.valueOf(box.getSelectedItem());
            
            
            if(!message.isEmpty()){
                castVote(message);
                text.setText("");
            }else if(!selCar.equals("Select")){
                castVote(selCar);
                box.setSelectedIndex(0);
            }else{
                selectionCounts.put(message, 1);
            } 
        }
        if(e.getSource() == view){
            data = dao.getAll();
            model = (DefaultTableModel)table.getModel();
            model.setRowCount(0);
            for(Server s : data){
                String car = s.myMsg;
                int votee = s.votes;
                Object[] carData = {car,votee};
                model.addRow(carData);
            }
        }
        if (e.getSource() == exit) {
            System.exit(0);
    }
    }
    private void updateDisplay() {
        taClient.setText("");
        for (String car : selectionCounts.keySet()) {
            taClient.append("Car: " + car + " | Votes: " + selectionCounts.get(car) + "\n");
        
            /*GUIClass s = new GUIClass(car, votes);
            GUIClass a = data.save(s);*/
        }
    }
    private void castVote(String car){
        
        selectionCounts.put(car, selectionCounts.getOrDefault(car,0) + 1);
        cl.sendVote(car, selectionCounts.getOrDefault(car, 0));
        updateDisplay();
        if(car.equalsIgnoreCase("terminate")){
            cl.closeConnection();
            System.exit(0);
        }
    }
    public String getTextInput() {
        return text.getText();
    }

    public int getVotesForCar(String car) {
        return selectionCounts.getOrDefault(car, 0);
    }
    
    public void appendText(String msg){
        taClient.append(msg);
    }
        
    
    public static void main(String[] args) {
        GUIClass gui = new GUIClass();
        gui.setGUI();
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setVisible(true);
        gui.setSize(500, 500);
        
        Client clt = new Client(gui);
        gui.cl = clt;
        try {
            clt.communicate();
        } catch (IOException ex) {
            Logger.getLogger(GUIClass.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    

}
