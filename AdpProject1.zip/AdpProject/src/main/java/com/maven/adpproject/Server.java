
package com.maven.adpproject;

import java.net.*;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {
    private ServerSocket socket;
    private Socket client;
    protected static ObjectOutputStream out;
    protected static ObjectInputStream in;
     String myMsg;
     int votes;
    DatabaseHandler dbh;
    
   
    
    public Server(){
        dbh = new DatabaseHandler();
        try {
            socket = new ServerSocket(6666);
        } catch (IOException ex) {
            System.out.println("Error; " + ex.getMessage());
        }
    }

    public Server(String myMsg, int votes) {
        this.myMsg = myMsg;
        this.votes = votes;
    }
    public void listen() throws IOException{
        System.out.println("Server is listening for request");
        client = socket.accept();
        System.out.println("Waiting for client data");
        processClient();
      
    }
    public void getStreams() throws IOException{
        out = new ObjectOutputStream(client.getOutputStream());
        out.flush();
        in =  new ObjectInputStream(client.getInputStream()); 
    }
    private void processClient(){
        try{
            getStreams();
            while(true){
                myMsg = (String)in.readObject();
                votes = (Integer)in.readObject();
                System.out.println("Data from client: " + myMsg + "| Votes"+votes);
                if(!myMsg.equalsIgnoreCase("terminate")){
                    dbh.save(new Server(myMsg, votes));
                    String response = "";
                    out.writeObject(response);
                    out.flush();
                }else{
                    System.out.println("Client requested to terminate the connection.");
                    break;
                }
            }
                
        } catch (ClassNotFoundException ex) {
            System.out.println("Action cannot be perfomed");
        }catch (IOException ex) {
                System.out.println("Connection was closed automatically");
        }finally{
            closeConnection();
        }
    }            
    
        public void closeConnection(){
        try {
            out.close();
            in.close();
            client.close();
        } catch (IOException ex) {
            System.out.println("Error"+ex.getMessage());
        }
    }
    public static void main(String[] args) throws IOException{
        Server serverApp = new Server();
        serverApp.listen();
    }

    
}

