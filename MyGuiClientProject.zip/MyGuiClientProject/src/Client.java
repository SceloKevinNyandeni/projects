/**
 * @author Wilhelm Rothman
 * 
 * Modified Code by Radford
*/

import java.io.*;
import java.net.*;

public class Client  {

/*  The protected keyword is an access modifier used for attributes, 
    methods and constructors, making them accessible in the same class,
    its subclasses, and the same package.
*/
    protected static ObjectInputStream in;
    protected static ObjectOutputStream out;
    private Socket socket;
    private String response;

    public Client() {
        // Step 1: Connect to the server, obtain a Socket object.

    }//end constructor

    private void getStreams() throws IOException {
        //construct stream objects for data transfer

    }//end method

    public void communicate() {
        // Step 2: The connection has been established - now set up streams

        do {
            
    /* 
    Step 3: Communicate with client. Since this is a GUI-driven client 
    application, it is only necessary to continously read from the server until
    the value 'terminate' is read. Writing to the server takes place when the
    user clicks on the textfield, so the code to send data is in the actionPerformed method.             
    */


        } while (!response.equalsIgnoreCase("TERMINATE"));

        // Step 4: close down

    }//end method

    private void closeConnection() {
        //close streams and socket

    }//end method
}//end class
