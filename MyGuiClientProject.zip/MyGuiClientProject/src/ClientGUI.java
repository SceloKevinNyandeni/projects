/**
 * @author Wilhelm Rothman
 * Modified Code by Radford
*/
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ClientGUI extends JFrame implements ActionListener {

    private JPanel pnlTop;
    private JPanel pnlBottom;
    private JLabel lblClient;
    private JTextField txtClient;
    protected static JTextArea taClient;
/*  The protected keyword is an access modifier used for attributes, 
    methods and constructors, making them accessible in the same class,
    its subclasses, and the same package.
*/  
    
    public ClientGUI() {
        //construct swing objects

    }
    
    public void setGUI() {
        //design GUI        
 
    }//end constructor
    
     @Override
    public void actionPerformed(ActionEvent e)
    {
        //what happens when user presses <enter> from textfield?
 
    }//end method
    
    private void sendData(String myMsg)
    {
        //send a text value to the server
        
    }//end method
   }//end class
