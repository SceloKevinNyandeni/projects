import javax.swing.JFrame;
/**
 * @author Wilhelm Rothman
 */
public class runClientGUI {

    public static void main(String args[]) {
        //construct a ClientGUI object and make it visible
        
        //construct a Client object to execute the client methods/services

    }// end main
}
