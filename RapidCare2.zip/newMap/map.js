
var map = L.map('map').setView([-33.9249, 18.4241], 12); 

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
}).addTo(map);

var hospitals = {
    "Groot Schuur Hospital": [-33.9391, 18.4623],
    "Stanger Public Hospital": [-29.3358, 31.2928],
    "Khayelitsha Community Clinic": [-34.0483, 18.6705],
    "Red Cross War Memorial Children's Hospital": [-33.9461, 18.4784],
    "New Somerset Hospital": [-33.9076, 18.4124],
    "Victoria Hospital": [-34.0122, 18.4617],
    "Groote Schuur Hospital": [-33.9280, 18.4463],
    "Netcare Christiaan Barnard Memorial Hospital": [-33.9208, 18.4213]
    
};

for (var hospital in hospitals) {
    L.marker(hospitals[hospital]).addTo(map)
        .bindPopup(hospital)
        .openPopup();
}

function locateHospital(hospitalName) {
    var location = hospitals[hospitalName];
    if (location) {
        map.setView(location, 15);
        L.popup()
            .setLatLng(location)
            .setContent(hospitalName)
            .openOn(map);
    }
}


function searchHospital() {
    var searchQuery = document.getElementById('searchInput').value.toLowerCase();
    var found = false;

    for (var hospital in hospitals) {
        if (hospital.toLowerCase().includes(searchQuery)) {
            locateHospital(hospital);
            found = true;
            break;
        }
    }

    if (!found) {
        alert("Hospital not found.");
    }
}


function requestAmbulance() {
    alert('Ambulance requested!');
}
