<?php
include 'db.php';

$stmt = $pdo->query("SELECT stage FROM delivery_status WHERE id = 1");
$currentStage = $stmt->fetch()['stage'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Delivery Tracking</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
  
 <div class="page-wrapper">
    <div class="header">
      <h1>YOUR ORDER IS ON THE WAY</h1>
    </div>
     <div class="instructions"> <p>Track your shipment below to see your delivery status.</p> </div>

    <div class="content">
      <div class="estimated-delivery">

        <div>
        <h2>ESTIMATED DELIVERY</h2>
        <p>Still Calculating</p>
        <p>CHECK BACK SOON</p>
      </div>
      <button class="track-button">Track My Package</button>
    </div>
<br>
    <div class="progress-container">
       <div class="timeline">
        <?php
        $stages = ['Order Processed','Order Shipped','Order En Route','Order Arrived'];
        foreach ($stages as $i =>$stage) {
          $stepNum = $i + 1;
          $class = '';
          if ($currentStage >$stepNum) $class = 'completed';
          if ($currentStage == $stepNum) $class = 'active';
          $icons = ['📄','📦','🚚','✅'];
          echo "<div class='timeline-step $class'>
                <div class='icon'>{$icons[$i]}</div>
                <div class='content'>{$stage}</div>
          </div>";
          
        }
        ?>
        </div>    
        </div>
    </div>
  </div>

<script>
setInterval(() => {
  fetch('get_stage.php')
    .then(res => res.json())
    .then(data => {
      const steps = document.querySelectorAll('.timeline-step');
      const timeline = document.querySelector('.timeline');

      const currentStage = data.stage;

      steps.forEach((step, i) => {
        step.classList.remove('completed','active');
        if(i + 1 < currentStage) step.classList.add('completed');
        if(i + 1 == currentStage) step.classList.add('active');
      });

      const activeIndex = currentStage - 1;
      const stepHeight = steps[0].offsetHeight + 40; 
      const fillHeight = Math.max(0, activeIndex * stepHeight);
      
      timeline.style.setProperty('--fill-height', `${fillHeight}px`);
    });
}, 2000);
</script>
</body>
</html>
