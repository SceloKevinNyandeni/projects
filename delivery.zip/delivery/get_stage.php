<?php
include 'db.php';
$stmt = $pdo->query("SELECT from delivery_status WHERE id =1");
$currentStage = $stmt->fetch()['stage'];
echo json_encode(['stage' => (int)$currentStage]);