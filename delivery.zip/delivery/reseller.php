<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['stage'])) {
  $stage = (int) $_POST['stage'];
   if ($stage >= 1 && $stage <= 4){
    $stmt = $pdo->prepare("UPDATE delivery_status SET stage = ? WHERE id = 1");
    $stmt->execute ([$stage]);
   } 
   header('Location: reseller.php');
   exit;

}

$stmt = $pdo->query("SELECT stage FROM delivery_status WHERE id = 1");
$currentStage = $stmt->fetch()['stage'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<style>
    body { padding: 20px; }
    button { padding: 10px 20px; margin: 5px; font-size: 16px; cursor: pointer; }
</style>
</head>
<body>
<h1>Reseller Page</h1>
<p>Click a button to set the delivery stage:</p>

<form method="post">
    <button type="submit" name="stage" value="1">Stage 1: Order Processed 📄</button>
    <button type="submit" name="stage" value="2">Stage 2: Order Shipped 📦</button>
    <button type="submit" name="stage" value="3">Stage 3: Order En Route 🚚</button>
    <button type="submit" name="stage" value="4">Stage 4: Order Arrived ✅</button>
</form>

<p>Current Stage: <?php echo $currentStage; ?></p>
</body>
</html>
